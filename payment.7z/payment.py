"""
PayPal payment handler for ClipBot V2
Handles subscription payments and activation
"""

import os
import logging
import requests
import base64
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class PayPalHandler:
    def __init__(self):
        self.client_id = os.getenv('PAYPAL_CLIENT_ID')
        self.secret = os.getenv('PAYPAL_SECRET')
        self.base_url = "https://api-m.paypal.com"  # Production
        # For testing, use: "https://api-m.sandbox.paypal.com"
        
        if not self.client_id or not self.secret:
            logger.warning("PayPal credentials not found in environment")
    
    def get_access_token(self):
        """Get PayPal OAuth access token"""
        try:
            auth = base64.b64encode(
                f"{self.client_id}:{self.secret}".encode()
            ).decode()
            
            headers = {
                "Authorization": f"Basic {auth}",
                "Content-Type": "application/x-www-form-urlencoded"
            }
            
            response = requests.post(
                f"{self.base_url}/v1/oauth2/token",
                headers=headers,
                data={"grant_type": "client_credentials"}
            )
            
            if response.status_code == 200:
                return response.json()['access_token']
            else:
                logger.error(f"Failed to get access token: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting access token: {e}")
            return None
    
    def create_payment(self, tier: str, user_id: int, username: str = None):
        """
        Create PayPal payment for subscription
        
        Args:
            tier: Subscription tier (basic, professional, advanced)
            user_id: Telegram user ID
            username: Telegram username (optional)
            
        Returns:
            dict with payment URL and order ID
        """
        try:
            # Tier prices
            prices = {
                'basic': '5.00',
                'professional': '10.00',
                'advanced': '15.00'
            }
            
            if tier not in prices:
                return {
                    'success': False,
                    'error': 'Invalid tier'
                }
            
            access_token = self.get_access_token()
            if not access_token:
                return {
                    'success': False,
                    'error': 'Failed to authenticate with PayPal'
                }
            
            # Create order
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            }
            
            order_data = {
                "intent": "CAPTURE",
                "purchase_units": [{
                    "reference_id": f"{user_id}_{tier}_{int(datetime.now().timestamp())}",
                    "description": f"ClipBot V2 - {tier.title()} Subscription (30 days)",
                    "amount": {
                        "currency_code": "USD",
                        "value": prices[tier]
                    }
                }],
                "application_context": {
                    "brand_name": "ClipBot V2",
                    "landing_page": "NO_PREFERENCE",
                    "user_action": "PAY_NOW",
                    "return_url": f"https://t.me/ClipotV2_bot?start=payment_success",
                    "cancel_url": f"https://t.me/ClipotV2_bot?start=payment_cancel"
                }
            }
            
            response = requests.post(
                f"{self.base_url}/v2/checkout/orders",
                headers=headers,
                json=order_data
            )
            
            if response.status_code == 201:
                order = response.json()
                
                # Get approval URL
                approval_url = None
                for link in order['links']:
                    if link['rel'] == 'approve':
                        approval_url = link['href']
                        break
                
                return {
                    'success': True,
                    'payment_url': approval_url,
                    'order_id': order['id']
                }
            else:
                logger.error(f"Failed to create order: {response.text}")
                return {
                    'success': False,
                    'error': 'Failed to create payment'
                }
                
        except Exception as e:
            logger.error(f"Error creating payment: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def capture_payment(self, order_id: str):
        """
        Capture (complete) a PayPal payment
        
        Args:
            order_id: PayPal order ID
            
        Returns:
            dict with success status and payment details
        """
        try:
            access_token = self.get_access_token()
            if not access_token:
                return {
                    'success': False,
                    'error': 'Failed to authenticate with PayPal'
                }
            
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            }
            
            response = requests.post(
                f"{self.base_url}/v2/checkout/orders/{order_id}/capture",
                headers=headers
            )
            
            if response.status_code == 201:
                capture = response.json()
                
                # Extract payment details
                reference_id = capture['purchase_units'][0]['reference_id']
                amount = capture['purchase_units'][0]['payments']['captures'][0]['amount']['value']
                
                # Parse reference_id to get user_id and tier
                parts = reference_id.split('_')
                user_id = int(parts[0])
                tier = parts[1]
                
                return {
                    'success': True,
                    'user_id': user_id,
                    'tier': tier,
                    'amount': amount,
                    'order_id': order_id,
                    'capture_id': capture['purchase_units'][0]['payments']['captures'][0]['id']
                }
            else:
                logger.error(f"Failed to capture payment: {response.text}")
                return {
                    'success': False,
                    'error': 'Failed to capture payment'
                }
                
        except Exception as e:
            logger.error(f"Error capturing payment: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def verify_payment(self, order_id: str):
        """
        Verify payment status
        
        Args:
            order_id: PayPal order ID
            
        Returns:
            dict with payment status
        """
        try:
            access_token = self.get_access_token()
            if not access_token:
                return {
                    'success': False,
                    'error': 'Failed to authenticate with PayPal'
                }
            
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            }
            
            response = requests.get(
                f"{self.base_url}/v2/checkout/orders/{order_id}",
                headers=headers
            )
            
            if response.status_code == 200:
                order = response.json()
                status = order['status']
                
                return {
                    'success': True,
                    'status': status,
                    'order': order
                }
            else:
                logger.error(f"Failed to verify payment: {response.text}")
                return {
                    'success': False,
                    'error': 'Failed to verify payment'
                }
                
        except Exception as e:
            logger.error(f"Error verifying payment: {e}")
            return {
                'success': False,
                'error': str(e)
            }
